#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void *Print(void *threadid) //fun��o a ser executada quando uma thread for criada
{
    long id;
    int i;
    id = (long)threadid;//convers�o de void pra long
    for(i=0; i<10; i++)
    {
        sleep(1);
        printf("Thread %ld - Executando\n", id);
    }
    pthread_exit(NULL); //finaliza��o da thread
}

int main()
{
    pthread_t t1, t2, t3; //criando t1 e t2 do tipo thread
    int create; //vari�vel que recebe o retorno da fun��o pthread_create()
    long num; //identificador da thread
    num = 1;
    printf("Main: criando a thread %ld\n", num);
    create = pthread_create(&t1, NULL, Print, (void*)num); //criando thread 1

    num = 2;
    printf("Main: criando a thread %ld\n", num);
    create = pthread_create(&t1, NULL, Print, (void *)num); //criando thread 2

    num = 3;
    printf("Main: criando a thread %ld\n", num);
    create = pthread_create(&t3, NULL, Print, (void *)num); //criando thread 3

    pthread_join (t1,NULL);
    pthread_join (t2,NULL);
    pthread_join (t3,NULL);
    printf("Main: finalizando\n");
    return 0;
}
