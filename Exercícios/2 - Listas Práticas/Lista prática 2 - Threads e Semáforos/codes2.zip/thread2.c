#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

int vet[6] = {0,0,0,0,0,0};


void *threadFunc(void *arg)
{
    vet[0] = 10;
    vet[1] = 20;
    vet[2] = 30;
}

void *threadFunc2(void *arg)
{
    vet[3] = 40;
    vet[4] = 50;
    vet[5] = 60;
}

int main()
{
    pthread_t t1,t2;
    int s,i;    
    s = pthread_create(&t1, NULL, threadFunc, NULL);//criando
    s = pthread_create(&t2, NULL, threadFunc2, NULL);//criando
    s = pthread_join(t1, NULL);//esperando elas terminares
    s = pthread_join(t2, NULL);//esperando elas terminares

    for(i=0; i<6; i++)
    {
        printf("[%d]\t",vet[i]);
    }
    printf("\n");
    printf("Main: finalizando\n");
    return 0;
}
