#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h> //biblioteca
#define N 100000

long n = 0;//memoria compartilhada
sem_t sem; //declara��o

//funcao que vai executar em paralelo
void *threadFunc(void *arg)
{
    for (long j = 0; j < N; j++) {	
        sem_wait(&sem); //entrar na sess�o cr�tica 
        n = n + 1; //incrementando 1 (condicao de corrida)	
	sem_post(&sem); //sair da sess�o cr�tica		
    }
}

//funcao que vai executar em paralelo
void *threadFunc2(void *arg)
{
    for (long j = 0; j < N; j++) {	
        sem_wait(&sem); //entrar na sess�o cr�tica	
        n = n - 1; //decrementando 1 (condicao de corrida)	
	sem_post(&sem); //sair da sess�o cr�tica		
    }
}


int main() {
    pthread_t t1,t2;
    int s;

	sem_init(&sem, 0, 1);//inicializar semaforo (main)    
        s = pthread_create(&t1, NULL, threadFunc, NULL);//criando
        s = pthread_create(&t2, NULL, threadFunc2, NULL);//criando
        s = pthread_join(t1, NULL);//esperando elas terminares
        s = pthread_join(t2, NULL);//esperando elas terminares
 

    printf("n = %ld\n",n);
}
