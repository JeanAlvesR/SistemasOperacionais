#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#define N 100000

long n = 0;//memoria compartilhada

//funcao que vai executar em paralelo
void *threadFunc(void *arg)
{
    for (long j = 0; j < N; j++) {	
        n = n + 1;			
    }
}

//funcao que vai executar em paralelo
void *threadFunc2(void *arg)
{
    for (long j = 0; j < N; j++) {	
        n = n - 1; //decrementando 1 (condicao de corrida)			
    }
}


int main() {
    pthread_t t1,t2;
    int s;
     
        s = pthread_create(&t1, NULL, threadFunc, NULL);//criando
        s = pthread_create(&t2, NULL, threadFunc2, NULL);//criando
        s = pthread_join(t1, NULL);//esperando elas terminares
        s = pthread_join(t2, NULL);//esperando elas terminares
 

    printf("n = %ld\n",n);
}
