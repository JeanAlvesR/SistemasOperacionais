#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int vet[4] = {0,0,0,0};

int main()
{
    pid_t iPid;
    int i;

    printf("\nDuplicando o processo\n");

    iPid = fork();
    if (iPid < 0)
    {
        exit(0); //erro ao criar o subprocesso.
    }

    if(iPid != 0)
    {
        /* este trecho de código será executado apenas no pai */
        printf("\nCodigo executado no processo pai\n");
        printf("\nPAI -Processo pai.  PID:|%d|\n", getpid());
        printf("\nPAI -Processo filho.PID:|%d|\n", iPid);
        vet[0] = 30;
        vet[1] = 40;
    }

    /* este trecho de código será executado apenas no filho, embora o comando if esteja disponível também para o pai */
    if(iPid == 0)
    {
        printf("\nCodigo executado no processo filho\n");
        printf("\nFILHO-Processo pai.  PID:|%d|\n",getppid());
        printf("\nFILHO-Processo filho.PID:|%d|\n",getpid());
        vet[2] = 10;
        vet[3] = 20;
    }

    /* este código está disponível no pai e no filho */
    printf("\nEste mensagem será impressa 2 vezes\n");
    for(i=0; i<4; i++)
    {
        printf("[%d]\t",vet[i]);
    }
    printf("\n");
    return 0;
}

