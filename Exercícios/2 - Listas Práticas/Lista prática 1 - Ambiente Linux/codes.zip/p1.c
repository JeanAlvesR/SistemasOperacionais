#include <stdio.h>
int main()
{
    int a=0;
    printf("Rodando...\n");
    while(1)
    {
        a = a + 1;
    }
}
